#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

import sensor_msgs.msg as sensor_msgs
from sensor_msgs_py import point_cloud2 as pc2
from sensor_msgs.msg import PointCloud2, PointField


class IntensityFilter(Node):
    def __init__(self):
        super().__init__('intensity_filter')

        # 구독자/퍼블리셔
        self.sub = self.create_subscription(
            PointCloud2,
            '/velodyne_points',
            self.callback,
            10
        )
        self.pub = self.create_publisher(PointCloud2, '/filtered_points', 10)

        self.get_logger().info("✅ Intensity filter node started")

    def callback(self, msg: PointCloud2):
        # PointCloud2 -> generator
        points = pc2.read_points(msg, field_names=('x', 'y', 'z', 'intensity'), skip_nans=True)

        # intensity 필터링 (예: 100 이상만)
        filtered = [p for p in points if p[3] > 100.0]

        # 새 PointCloud2 메시지 생성
        header = msg.header
        fields = [
            PointField(name='x', offset=0,  datatype=PointField.FLOAT32, count=1),
            PointField(name='y', offset=4,  datatype=PointField.FLOAT32, count=1),
            PointField(name='z', offset=8,  datatype=PointField.FLOAT32, count=1),
            PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1),
        ]

        pc2_msg = pc2.create_cloud(header, fields, filtered)

        self.pub.publish(pc2_msg)


def main(args=None):
    rclpy.init(args=args)
    node = IntensityFilter()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
